import edu.princeton.cs.algs4.StdRandom;

/**
 * 
 * @author Shashwat Koranne
 * 
 * Code writen in this file is the solution to the assigment 1 for the course,
 * 'Algorithms I' hosted on coursera.org by Princeton University.
 * 
 */
public class PercolationStats {
	Percolation myPerc;
	int gridSize;
	int numberOfTrials;
	double[] openSites;
	public PercolationStats(int n, int trials) {
		this.gridSize = n * n;
		this.numberOfTrials = trials;
		openSites = new double[trials];
		for (int i = 0; i < trials; i++) {
			myPerc = new Percolation(n);
			while(!myPerc.percolates()) {
				int cellIndex = StdRandom.uniform(gridSize);
				int row = (int) cellIndex / n + 1;
				int col = (int) cellIndex % n + 1;
				myPerc.open(row, col);
			}
			openSites[i] = (double) myPerc.numberOfOpenSites / this.gridSize;
		}
	}
	
	public double mean() {
		
		int length = openSites.length;
		double sumOfOpenSites = 0.0;
		for (int i = 0; i < length; i++) {
			sumOfOpenSites = sumOfOpenSites + openSites[i];
		}
		double mean = (double) sumOfOpenSites / numberOfTrials;
		return mean;
	}
	
	public double stddev() {
		double mean = mean();
		int length = openSites.length;
		double sumOfSquares = 0;
		for (int i = 0; i < length; i++) {
			double square = Math.pow((openSites[i] - mean), 2);
			sumOfSquares = sumOfSquares + square;
		}
		double variance = sumOfSquares / (numberOfTrials - 1);
		double stddev = Math.sqrt(variance);
		return stddev;
	}
	
	public double confidenceLo() {
		double mean = mean();
		double stddev = stddev();
		double trialSqrt = Math.sqrt(numberOfTrials);
		double val = 1.96 * stddev / trialSqrt;
		double confidenceLo = mean - val;
		return confidenceLo;
	}
	
	public double confidenceHi() {
		double mean = mean();
		double stddev = stddev();
		double trialSqrt = Math.sqrt(numberOfTrials);
		double val = 1.96 * stddev / trialSqrt;
		double confidenceHi = mean + val;
		return confidenceHi;
	}
	
	public static void main(String[] args) {
		PercolationStats stat = new PercolationStats(5000, 100);
		double mean = stat.mean();
		double stddev = stat.stddev();
		double lo = stat.confidenceLo();
		double hi = stat.confidenceHi();
		System.out.println("mean = " + mean);
		System.out.println("stddev = " + stddev);
		System.out.println("confidence interval = " + lo + ", " + hi);
	}
}
